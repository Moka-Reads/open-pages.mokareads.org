---
title: "Strategic Pricing For Multi Platform Digital Publishing: A Penalty Reward Optimization Approach"
status: working
tags:
  - Optimization
  - Non-linear Programming
github: ""
pdf: ""
purchase: ""
authors:
- name: "Mustafif Khan"
  affiliation: "MoKa Reads Collective"
---

## Summary

Developing an optimization problem for determining optimal pricing strategies across several digital publishing platforms.

## Abstract

TBD

## Table of Contents

TBD
